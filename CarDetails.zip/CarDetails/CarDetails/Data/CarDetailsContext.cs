﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CarDetails.Models;

namespace CarDetails.Data
{
    public class CarDetailsContext : DbContext
    {
        public CarDetailsContext (DbContextOptions<CarDetailsContext> options)
            : base(options)
        {
        }

        public DbSet<CarDetails.Models.CarDetail> CarDetail { get; set; }
    }
}
