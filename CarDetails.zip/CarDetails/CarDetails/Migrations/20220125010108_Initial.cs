﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CarDetails.Migrations
{
    public partial class Initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CarDetail",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Engine = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Transmission = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Company = table.Column<int>(type: "int", nullable: false),
                    Battery = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Alternator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Radiator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Suspension = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CarDetail", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CarDetail");
        }
    }
}
