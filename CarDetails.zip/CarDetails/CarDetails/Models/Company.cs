﻿using System.ComponentModel.DataAnnotations;

namespace CarDetails.Models
{
    public enum Company
    {
        Subaru,
        Honda,
        Jeep,
        Toyota,
        Volkswagen,
        Ford
    }
}
