﻿using System.ComponentModel.DataAnnotations;

namespace CarDetails.Models
{
    public class CarDetail
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Engine { get; set; }

        [Required]
        public string Transmission { get; set; }

        [Required]
        public Company Company { get; set; }

        [Required]
        public string Battery { get; set; }

        [Required]
        public string Alternator { get; set; }

        [Required]
        public string Radiator { get; set; }

        [Required]
        public string Suspension { get; set; }
    }
}
